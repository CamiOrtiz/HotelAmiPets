from django.urls import path, include
from .views import home,base,acceso, Reserva,huesped,cliente, agendar, index, listarCliente, listarHuesped, funcionario, listarFuncionarios, modificarCliente, modificarHuesped,calcularTarifa, base2, nosotros, estadias, listaReserva, modificarReservas, vacunas, listar_vacunas, modificarVacuna, listar_estadia, procesar_formulario, correo, histReserva, histPago, generar_pdf, generar_pdf2, FichaPetViewset, buscar_cliente, funcionariosIndex
from django.contrib.auth.decorators import login_required
from rest_framework import routers

router = routers.DefaultRouter()
router.register('fichaPet', FichaPetViewset)



urlpatterns = [
    path('', index, name="index"),
    path('acceso/', login_required (acceso), name="acceso"),    
    path('reserva/', login_required (Reserva), name="reserva"),
    path('huesped/', login_required(huesped), name="huesped"),
    path('cliente/', login_required(cliente), name="cliente"),
    path('base/', login_required(base), name='base'),
    path('agenda/', login_required (agendar), name='agenda'),
    path('home/', login_required(home), name='home'),
    path('listar/', login_required(listarCliente), name='listar'),
    path('listarHuesped/', login_required(listarHuesped), name='listarHuesped'),
    path('funcionario/', login_required(funcionario), name='funcionario'),
    path('listarFuncionarios/', login_required(listarFuncionarios), name='listarFuncionarios'),
    path('modificarCliente/<id>/', login_required(modificarCliente), name='modificarCliente'),
    path('modificarHuesped/<id>/', login_required(modificarHuesped), name='modificarHuesped'),
    path('calcular_tarifa/', login_required(calcularTarifa), name='calcular_tarifa'),
    path('resultado/', login_required(calcularTarifa), name='resultado'),
    path('nosotros/', nosotros, name='nosotros'),
    path('base2/',base2, name='base2'),
    path('estadia/', login_required(estadias), name='estadia'),
    path('lista_reserva/', login_required(listaReserva), name='lista_reserva'),
    path('modificarReserva/<id>/', login_required(modificarReservas), name='modificarReserva'),
    path('vacuna/', login_required(vacunas), name='vacuna'),
    path('listar_vacuna/', login_required(listar_vacunas), name='listar_vacuna'),
    path('modificarVacuna/<int:id>/', login_required(modificarVacuna), name='modificarVacuna'),
    path('listar_estadia/', login_required(listar_estadia), name='listar_estadia'),
    path('confirmacion/', login_required(procesar_formulario), name='confirmacion'),
    path('correo/', login_required(correo), name='correo'),
    path('hreserva/', login_required(histReserva), name='hreserva'),
    path('historicos_p/', login_required(histPago), name='historicos_p'),
    path('generar_pdf/', login_required(generar_pdf), name='generar_pdf'),
    path('generar_pdf2/', login_required(generar_pdf2), name='generar_pdf2'),
    path ('api/', include(router.urls)),
    path('buscar-cliente/', login_required(buscar_cliente), name='buscarCliente'),
    path('funcionariosIndex/', funcionariosIndex, name='funcionariosIndex'),
    ] 