from django.shortcuts import render, redirect, get_object_or_404
from requests import request
from .forms import PersonaForm, FichapetForm, FuncionarioForm, ReservaForm, EstadiaForm, VacunaForm, ReservaModificacionForm
from .models import Persona, ficha_pet, Funcionario, Tarifa, reserva, estado, Vacuna, estadia, Hist_reserva, Hist_pago
from django.contrib import messages
from datetime import date
from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import render_to_string
from django.db import connection
from django.http import HttpResponse
from reportlab.pdfgen import canvas
from django.db.models import Sum
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib import colors
from datetime import timedelta
from rest_framework import viewsets
from .serializers import FichaPetSerializer
from django.db.models import Q

# Create your views here.

class FichaPetViewset(viewsets.ModelViewSet):
    queryset = ficha_pet.objects.all()
    serializer_class = FichaPetSerializer


def home(request):
    return render(request, 'core/home.html')

def funcionariosIndex(request):
    funcionarios = Funcionario.objects.all()

    data = {
        'funcionarios' : funcionarios 
    }
    return render (request,'core/listar/funcionariosIndex.html', data)
           
   
def acceso(request):
    return render(request, 'core/acceso.html')

def base(request):
    return render(request, 'core/base.html')

def index(request):
    return render(request, 'core/index.html')

def correo(request):
    return render(request, 'core/correo.html')

def base2(request):
    return render(request, 'core/base2.html')

def Reserva(request):
    data = {
        'form': ReservaForm()
    }
    if request.method == 'POST':
        formulario = ReservaForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, "Guardado con éxito")
        else:
            data['form'] = formulario
            

    return render(request, 'core/reserva.html', data)

def listaReserva(request):
    reservas = reserva.objects.all()

    data = {
        'reservas' : reservas
    }
    return render (request,'core/listar/lista_reserva.html', data)

def modificarReservas(request, id):
    reservas = get_object_or_404(reserva, id=id)

    data = {
        'form': ReservaModificacionForm(instance=reservas)
    }
    if request.method == 'POST':
        formulario = ReservaModificacionForm(data=request.POST, instance=reservas)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, "Modificado correctamente")
            return redirect(to="lista_reserva")
        data["form"] = formulario
    
    return render(request, 'core/listar/modificarReserva.html', data)

def agendar (request):
    today = date.today()
    fecha_ini = reserva.objects.all()
    resultado_reservas = list(fecha_ini.values())
    print('resultado_reservas:', resultado_reservas)
    reservas = []
    for item in resultado_reservas:
        persona = Persona.objects.get(pk=item['persona_id'])
        estados = estado.objects.get(pk=item ['estado_id'])
        fecha_term = item['fecha_term'] + timedelta(days=1)
        res = {
        'estado': estados.descrip_est,
        'nombre_persona': persona.nombres,
        'fecha_ini': item['fecha_ini'].strftime('%Y-%m-%d'),
        'fecha_term': fecha_term.strftime('%Y-%m-%d')
        }
        reservas.append(res)
    print('reservas:', reservas)
    return render(request, 'core/agenda.html', {'reserva_hoy': reservas})

def huesped(request):
    data = {
        'form': FichapetForm()
    }
    if request.method == 'POST':
        formulario = FichapetForm(data=request.POST, files= request.FILES)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, "Huesped ingresado correctamente")
            return redirect (to="listarHuesped")
            
        else:
            data["form"] = formulario

    return render(request, 'core/huesped.html', data)

def listarHuesped(request):
    huespedes = ficha_pet.objects.all()

    data = {
        'huespedes' : huespedes
    }
    return render (request,'core/listar/listarHuesped.html', data)

def modificarHuesped(request, id):

    huesped = get_object_or_404(ficha_pet, id=id)

    data = {
        'form' : FichapetForm(instance=huesped)
        }
    if request.method == 'POST':
        formulario = FichapetForm(data=request.POST, instance=huesped, files=request.FILES)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, "Modificado correctamente")
            return redirect (to="listarHuesped")
        data['form'] = formulario

    return render (request, 'core/listar/modificarHuesped.html', data )


def cliente(request):
    data = {
        'form': PersonaForm
    }
    if request.method == 'POST':
        formulario = PersonaForm(data= request.POST)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, "Cliente ingresado correctamente")
            return redirect (to="huesped")

        else:
            data["form"] = formulario

    return render(request, 'core/cliente.html', data)


def listarCliente(request):
    clientes = Persona.objects.all()

    data = {
        'clientes' : clientes
    }
    return render (request,'core/listar/listar.html', data)

def modificarCliente(request, id):
    
    persona = get_object_or_404(Persona, id=id)

    data = {
        'form': PersonaForm(instance=persona)
        }
    if request.method == 'POST':
        formulario = PersonaForm(data=request.POST, instance=persona, files=request.FILES)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, "Modificado correctamente")
            return redirect (to="listar")
        data["form"] = formulario
    
    return render (request, 'core/listar/modificarCliente.html', data)


def buscar_cliente(request):
    query = request.GET.get('query')

    if query:
        clientes = Persona.objects.filter(
            Q(rut__icontains=query) |
            Q(nombres__icontains=query) |
            Q(phone__icontains=query) |
            Q(mail__icontains=query) |
            Q(direccion__icontains=query) |
            Q(comuna__nombre_com__icontains=query)
        )
    else:
        clientes = Persona.objects.all()

    return render(request,'core/listar/listar.html', {'clientes': clientes, 'query': query})


def funcionario(request):

        data = {
        'form1': FuncionarioForm()
        }

        if request.method == 'POST':
            formulario = FuncionarioForm(data=request.POST, files= request.FILES)
            if formulario.is_valid():
                formulario.save()
                data["mensaje1"] = "guardado"
            else:
                data['form1'] = formulario


        return render(request, 'core/funcionario.html', data)

def listarFuncionarios(request):
    funcionarios = Funcionario.objects.all()

    data = {
        'funcionarios' : funcionarios 
    }
    return render (request,'core/listar/listarFuncionarios.html', data)

 
def calcularTarifa(request):
    
    if request.method == 'POST':
        try:
            numero = int(request.POST.get('numero'))
            tarifa_id = int(request.POST.get('tarifa'))
            tarifa = Tarifa.objects.get(pk=tarifa_id)
            resultado = tarifa.valor * numero
            
            data = {
                'tarifa': tarifa,
                'numero': numero,
                'resultado': resultado,
            }
        except Exception as e:
            print(e)
            data = {
                'tarifas':Tarifa.objects.all(),                
                'warning': messages.warning (request,'Por favor ingresa un valor'),
            }
            return render(request, 'core/tarifa/calcular_tarifa.html', data)
        return render(request, 'core/tarifa/resultado.html', data)

    tarifas = Tarifa.objects.all()
    data = {'tarifas': tarifas}
    return render(request, 'core/tarifa/calcular_tarifa.html', data)


def nosotros(request):
    tarifas = Tarifa.objects.all()

    context = {
        'tarifas': tarifas
        }
    return render(request, 'core/nosotros.html', context)
   
def listar_estadia(request):
    estadias = estadia.objects.all()

    return render(request, 'core/listar/listar_estadia.html', {'estadias': estadias})

def vacunas(request):
    data = {
        'form': VacunaForm()
    }
    if request.method == 'POST':
        formulario = VacunaForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, "Guardado con éxito")
        else:
            data['form'] = formulario
    return render(request, 'core/vacuna.html', data)

def listar_vacunas(request):
    vacunas = Vacuna.objects.all()

    data = {
        'vacunas': vacunas
    }
    return render(request, 'core/listar/listar_vacuna.html', data)


def modificarVacuna(request, id):
    vacunas = get_object_or_404(Vacuna, id=id)
    data = {
        'form': VacunaForm(instance=vacunas)
    }
    if request.method == 'POST':
        formulario = VacunaForm(data=request.POST, instance=vacunas)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, "Información modificada con éxito")
            return redirect(to="listar_vacuna")
        data["form"] = formulario
    return render(request, 'core/listar/modificarVacuna.html', data)

def estadias(request):
    data = {
        'form': EstadiaForm()
    }

    if request.method == 'POST':
        formulario = EstadiaForm(data=request.POST)
        if formulario.is_valid():
            estadia = formulario.save()

            # Cambiar el estado de la reserva a "confirmada"
            reserva_obj = estadia.cliente
            confirmada = estado.objects.get(id=21)
            reserva_obj.estado = confirmada
            reserva_obj.save()

            # Enviar correo electrónico de confirmación
            subject = 'Confirmación de reserva'
            message = render_to_string('core/correo.html', {
                'cliente': estadia.cliente,
                'cant_dias': estadia.cant_dias,
                'descrip_est': estadia.descrip_est,
                'monto_total': estadia.monto_total,
                'fech_pago': estadia.fech_pago,
            })
            from_email = settings.EMAIL_HOST_USER
            to_email = [estadia.mail]
            send_mail(subject, message, from_email, to_email, html_message=message, fail_silently=False)


            messages.success(request, "Estadía ingresada con éxito")
            return redirect('confirmacion')  # Redirigir a una página de confirmación

        else:
            data['form'] = formulario

    return render(request, 'core/estadia.html', data)

def procesar_formulario(request):
    if request.method == 'POST':
        form = EstadiaForm(request.POST)
        if form.is_valid():
            # Guardar los datos del formulario en la base de datos
            estadia = form.save()

            # Enviar correo electrónico de confirmación
            subject = 'Confirmación de reserva'
            message = render_to_string('core/correo.html', {
                'cliente': estadia.cliente,
                'cant_dias': estadia.cant_dias,
                'descrip_est': estadia.descrip_est,
                'monto_total': estadia.monto_total,
                'fech_pago': estadia.fech_pago,
            })
            from_email = settings.EMAIL_HOST_USER
            to_email = [estadia.mail]
            send_mail(subject, message, from_email, to_email, html_message=message, fail_silently=False)

            messages.success(request, "Estadía ingresada con éxito")
            return redirect('confirmacion')  # Redirigir a una página de confirmación

    else:
        form = EstadiaForm()

    return render(request, 'core/estadia.html', {'form': form})

def histReserva(request):
    with connection.cursor() as cursor:
        query = '''
            SELECT hr.id_hist_est, hr.fecha_ini, hr.fecha_term, hr.id_cliente, p.nombres
            FROM core_Hist_reserva hr
            INNER JOIN core_Persona p ON hr.id_cliente = p.id
        '''   
        cursor.execute(query)
        resultados = cursor.fetchall()
        
    datos_reservas = []   
    for resultado in resultados:
        id_hist_est = resultado[0]
        fecha_ini = resultado[1]
        fecha_term = resultado[2]
        id_cliente = resultado[3]
        nombres = resultado[4]
        
        
        datos_reservas.append({
            'id_hist_est': id_hist_est,
            'fecha_ini': fecha_ini,
            'fecha_term': fecha_term,
            'id_cliente': id_cliente,
            'nombres': nombres,
        })
    
    context = {
        'histreserva': datos_reservas,
    }
    return render (request,'core/hreserva.html', context)

def generar_pdf(request):
    # Obtener los datos de las reservas y contar la cantidad de veces que aparece una persona
    with connection.cursor() as cursor:
        query = '''
            SELECT hr.id_hist_est, hr.fecha_ini, hr.fecha_term, hr.id_cliente, p.nombres
            FROM core_Hist_reserva hr
            INNER JOIN core_Persona p ON hr.id_cliente = p.id
        '''
        cursor.execute(query)
        resultados = cursor.fetchall()
    
    datos_reservas = []
    contador_personas = {}
    for resultado in resultados:
        id_hist_est = resultado[0]
        fecha_ini = resultado[1]
        fecha_term = resultado[2]
        id_cliente = resultado[3]
        nombres = resultado[4]
        
        datos_reservas.append({
            'id_hist_est': id_hist_est,
            'fecha_ini': fecha_ini,
            'fecha_term': fecha_term,
            'id_cliente': id_cliente,
            'nombres': nombres,
        })
        
        # Contar la cantidad de veces que aparece una persona
        if nombres in contador_personas:
            contador_personas[nombres] += 1
        else:
            contador_personas[nombres] = 1
    
    # Generar el PDF con los datos y el contador
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="reporte_reservas.pdf"'
    
    p = canvas.Canvas(response)
    p.setFont('Helvetica', 12)
    
    # Agregar los datos de las reservas al PDF
    for reserva in datos_reservas:
        p.drawString(50, 700, f'ID Hist_est: {reserva["id_hist_est"]}')
        p.drawString(50, 680, f'Fecha inicio: {reserva["fecha_ini"]}')
        p.drawString(50, 660, f'Fecha término: {reserva["fecha_term"]}')
        p.drawString(50, 640, f'ID Cliente: {reserva["id_cliente"]}')
        p.drawString(50, 620, f'Nombre completo: {reserva["nombres"]}')
        p.showPage()
    
    # Agregar el contador de personas al PDF
    p.setFont('Helvetica', 16)
    p.drawString(50, 700, 'Contador de visitas por cliente:')
    
    y = 670
    for persona, cantidad in contador_personas.items():
        p.drawString(70, y, f'{persona}: {cantidad} reservas')
        y -= 20
    
    p.showPage()
    p.save()
    
    return response



def histPago(request):
    pagos = Hist_pago.objects.all()
    total_montos = pagos.aggregate(total=Sum('monto')).get('total')

    data = {
        'pagos': pagos,
        'total_montos': total_montos,
    }

    return render(request, 'core/hpago.html', data)


def generar_pdf2(request):
    pagos = Hist_pago.objects.all().order_by('id')
    total_montos = pagos.aggregate(total=Sum('monto')).get('total')

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="hist_pago.pdf"'

    doc = SimpleDocTemplate(response, pagesize=letter)
    elements = []

    # Crear el objeto canvas
    p = canvas.Canvas(response)
    y = 40

    # Encabezado de la tabla
    data = [['Id', 'Id estadia', 'Fecha pago', 'Monto']]
    for pago in pagos:
        data.append([pago.id, pago.id_estadia, pago.fecha_pago, pago.monto])

    # Agregar fila con el total
    data.append(['', '', 'total:', total_montos])

    # Estilo de la tabla
    table_style = TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),  # Encabezado de la tabla
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),  # Color del texto del encabezado
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),  # Alineación central del contenido de la tabla
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),  # Fuente en negrita para el encabezado
        ('FONTSIZE', (0, 0), (-1, 0), 12),  # Tamaño de fuente para el encabezado
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),  # Espaciado inferior para el encabezado
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),  # Color de fondo para las filas de datos
        ('GRID', (0, 0), (-1, -1), 1, colors.black),  # Líneas de cuadrícula
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),  # Fuente para el contenido de la tabla
        ('FONTSIZE', (0, 1), (-1, -1), 10),  # Tamaño de fuente para el contenido de la tabla
        ('TOPPADDING', (0, 0), (-1, -1), 6),  # Espaciado superior para todas las celdas
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),  # Espaciado inferior para todas las celdas
    ])


    # Crear la tabla
    table = Table(data)
    table.setStyle(table_style)

    # Agregar la tabla al documento
    elements.append(table)

    # Generar el PDF
    doc.build(elements)

    return response
