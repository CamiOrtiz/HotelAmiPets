from .models import ficha_pet
from rest_framework import serializers 

class FichaPetSerializer(serializers.ModelSerializer):
    class Meta:
        model = ficha_pet
        fields = '__all__'


